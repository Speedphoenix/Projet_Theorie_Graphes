var searchData=
[
  ['shrct',['shrct',['../namespacegrman.html#a704a62f445f057422a0b9883ef1b8a7c',1,'grman']]]
];

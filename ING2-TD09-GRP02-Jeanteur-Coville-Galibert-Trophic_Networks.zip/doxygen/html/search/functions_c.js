var searchData=
[
  ['send_5fstream',['send_stream',['../class_graph.html#ad2430a308293fbd34f50f7fd58dfcde7',1,'Graph']]],
  ['set_5fbg_5fcolor',['set_bg_color',['../classgrman_1_1_widget.html#ae8f8fc19b6b0981895c38fdf7df4e4bb',1,'grman::Widget']]],
  ['set_5fcolor',['set_color',['../classgrman_1_1_widget_text.html#a621fb4e0756cc183ee94d7c0d966ef90',1,'grman::WidgetText']]],
  ['set_5fno_5fgravity',['set_no_gravity',['../classgrman_1_1_widget.html#a61c632d3a7b2dee577e7a0be63fb16ff',1,'grman::Widget']]],
  ['set_5fselection',['set_selection',['../class_toolbox.html#ab317c98f39e2c1ff48c01a963df29e1f',1,'Toolbox']]],
  ['simplementconnexe',['simplementConnexe',['../class_graph.html#adee2a9ded840ee91b853e7f7076cbf67',1,'Graph']]]
];

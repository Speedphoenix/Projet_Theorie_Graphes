var searchData=
[
  ['widget',['Widget',['../classgrman_1_1_widget.html#acaf342823ead0ea00f300f86c16f92c0',1,'grman::Widget']]]
];

var searchData=
[
  ['coords',['Coords',['../struct_coords.html',1,'']]]
];

var searchData=
[
  ['post_5fupdate',['post_update',['../class_vertex.html#a68b740256d930792dccb31072e96f85f',1,'Vertex::post_update()'],['../class_edge.html#a4d172425eac4e94c78ab1bd66ba48d50',1,'Edge::post_update()']]],
  ['pre_5fupdate',['pre_update',['../class_vertex.html#adc6514220f5501e790a912f7d9c0d720',1,'Vertex::pre_update()'],['../class_edge.html#ab9f1fdf7c47051d419ea5b73bed0e21d',1,'Edge::pre_update()']]]
];

var classgrman_1_1_widget_button_text =
[
    [ "WidgetButtonText", "classgrman_1_1_widget_button_text.html#a29a7f15312af5a9d3c279db0c4579d91", null ],
    [ "get_message_widget", "classgrman_1_1_widget_button_text.html#a6c2e50e8e48ca3c673eadb97a935d993", null ],
    [ "m_message", "classgrman_1_1_widget_button_text.html#a6e57730df3f23baf7e356ddb327876ec", null ]
];
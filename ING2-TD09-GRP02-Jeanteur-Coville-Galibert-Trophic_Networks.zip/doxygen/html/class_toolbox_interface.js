var class_toolbox_interface =
[
    [ "ToolboxInterface", "class_toolbox_interface.html#a4749ef420310ab6232c4ba198497b114", null ],
    [ "Graph", "class_toolbox_interface.html#afab89afd724f1b07b1aaad6bdc61c47a", null ],
    [ "Toolbox", "class_toolbox_interface.html#aa6665ccf6156fcdb12d0b3ecb981bc7f", null ]
];
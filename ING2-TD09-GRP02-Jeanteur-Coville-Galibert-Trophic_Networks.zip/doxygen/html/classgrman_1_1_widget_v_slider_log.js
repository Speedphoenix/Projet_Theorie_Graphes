var classgrman_1_1_widget_v_slider_log =
[
    [ "get_value", "classgrman_1_1_widget_v_slider_log.html#a38ae9efa9721ab14467fd4e0b30acedc", null ],
    [ "set_value", "classgrman_1_1_widget_v_slider_log.html#ae62ecf8dbebc1f743ebc5b9e1af8f239", null ]
];
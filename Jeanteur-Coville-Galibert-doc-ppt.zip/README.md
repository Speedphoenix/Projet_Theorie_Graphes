# Trophic (and non trophic) Networks

A simple model for trophic and non-trophic interactions  
Made as an academic project with Bencow and gagaloulou  

A large portion of the code is adapted from code given by our teacher Robin Fercoq  

Ce projet est le fruit de la collaboration entre
	Leonardo Jeanteur
	Benoît Coville
	Louis Galibert


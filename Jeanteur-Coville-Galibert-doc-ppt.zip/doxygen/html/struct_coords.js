var struct_coords =
[
    [ "Coords", "struct_coords.html#a5922d1783cefa759950faa50ac347191", null ],
    [ "Coords", "struct_coords.html#a2711e0a680d31f9ba19baaea025897d8", null ],
    [ "norm", "struct_coords.html#a2d62e940e7ed4cb05a24d049170b9aa9", null ],
    [ "norm2", "struct_coords.html#a1ea0e81134f3d690bd448d8cf004993f", null ],
    [ "normalize", "struct_coords.html#a5cb214fa037c0e331feab38a578557e5", null ],
    [ "operator*", "struct_coords.html#ace147b80eedcc1cd7867d76bf6a075f5", null ],
    [ "operator*", "struct_coords.html#a40ca135b6dbb4ecbfbed263fd58d12a2", null ],
    [ "operator+", "struct_coords.html#ac944cc5d385b4d27737884bded760405", null ],
    [ "operator-", "struct_coords.html#a26ea503389f21fbc5d32a6163000d778", null ],
    [ "operator-", "struct_coords.html#a00802f49f80579898e20344ef0e352a2", null ],
    [ "operator/", "struct_coords.html#a2f3ad5162436a22c3af95e8baec7ef5a", null ],
    [ "operator/", "struct_coords.html#ad44e0635a9ef86ab5f655901e1d00d8c", null ],
    [ "rotate_90", "struct_coords.html#a2ebd98fed71466a261f524a69b2edb49", null ],
    [ "x", "struct_coords.html#a39be8f1e51668e2dcb4717e0d48b4622", null ],
    [ "y", "struct_coords.html#a657a9a238200f6fef66b4a491b7f86bc", null ]
];
var searchData=
[
  ['m_5fattach',['m_attach',['../classgrman_1_1_widget_edge.html#ac80f872a3c762175fb8067728faee007',1,'grman::WidgetEdge']]],
  ['m_5fchildren',['m_children',['../classgrman_1_1_widget.html#adaf4dd515f19c5c1c461ef39a8980c11',1,'grman::Widget']]]
];

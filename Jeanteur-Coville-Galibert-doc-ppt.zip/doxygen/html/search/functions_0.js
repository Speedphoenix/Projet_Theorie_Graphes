var searchData=
[
  ['add_5fedge',['add_edge',['../class_graph.html#ad76c924f4c5901a5f25feea320adddb7',1,'Graph']]],
  ['add_5finterfaced_5fedge',['add_interfaced_edge',['../class_graph.html#ad1b563f3849f5e973ffc9287063aad33',1,'Graph']]],
  ['add_5finterfaced_5fvertex',['add_interfaced_vertex',['../class_graph.html#a89aa07181664d37b851cc231d7eb19bd',1,'Graph::add_interfaced_vertex(Vertex &amp;source, int id)'],['../class_graph.html#ad977d1588cf6c12cfcd90d72368ca820',1,'Graph::add_interfaced_vertex(int idx, double val, double r, int x, int y, std::string name=&quot;&quot;, Vertex_type type=Vertex_type::Logistic, std::string pic_name=&quot;&quot;, int pic_idx=0)']]],
  ['add_5fitem',['add_item',['../classgrman_1_1_widget_edge.html#a86413db4c60fd85d249667b55f8d4d1a',1,'grman::WidgetEdge']]],
  ['add_5fvertex',['add_vertex',['../class_graph.html#aad35dc1b5705400d7e06af3b251fb1bf',1,'Graph::add_vertex(Vertex &amp;source, int id)'],['../class_graph.html#a079c11055ac0ebb65f5fc59ab7cdde65',1,'Graph::add_vertex(std::string name, int idx, double value, double r, Vertex_type type=Vertex_type::Logistic)']]]
];

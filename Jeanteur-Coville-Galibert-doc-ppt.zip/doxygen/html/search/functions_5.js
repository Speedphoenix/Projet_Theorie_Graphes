var searchData=
[
  ['get_5fchild',['get_child',['../classgrman_1_1_widget.html#acfd5cb20e83cb0cce4973530b467352b',1,'grman::Widget']]],
  ['get_5fpicture_5fnb',['get_picture_nb',['../namespacegrman.html#a2139034e3a5eaee44ba4409a53bc5ae6',1,'grman']]],
  ['get_5fquit',['get_quit',['../class_graph.html#adf06a6e39406dfb10bfd4267fb5467ab',1,'Graph']]],
  ['get_5fstream',['get_stream',['../class_graph.html#a5e44a26d2b87d58675eacf26a486e0ba',1,'Graph']]],
  ['graph',['Graph',['../class_graph.html#a6d716090e2ae19abf6b40b5f1a7f7f68',1,'Graph::Graph(GraphInterface *interface=nullptr)'],['../class_graph.html#ac4b7d27fc631a9992fd3fcdb5f56889e',1,'Graph::Graph(std::string filename)']]],
  ['graphinterface',['GraphInterface',['../class_graph_interface.html#afdc8c063edd6775ad16e5dc1b0597e9a',1,'GraphInterface']]]
];

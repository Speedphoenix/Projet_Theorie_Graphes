var class_toolbox =
[
    [ "Toolbox", "class_toolbox.html#a732158a621481bc50bb498dd02a1bdd6", null ],
    [ "post_update", "class_toolbox.html#a1bb78dda3d6bec128a4e2869a3c4974d", null ],
    [ "pre_update", "class_toolbox.html#a98a927e01931bf3819ccdf32eec5bacf", null ],
    [ "set_selection", "class_toolbox.html#ab317c98f39e2c1ff48c01a963df29e1f", null ],
    [ "Graph", "class_toolbox.html#afab89afd724f1b07b1aaad6bdc61c47a", null ]
];
var classgrman_1_1_widget_text =
[
    [ "WidgetText", "classgrman_1_1_widget_text.html#a0d5ab6d804da36fdf0bcdb2a097edfc3", null ],
    [ "draw", "classgrman_1_1_widget_text.html#af73e6a5dced3bd5ace8a99e0dd6c0e62", null ],
    [ "get_message", "classgrman_1_1_widget_text.html#aa18bd8b71ebf051c48535634d239e43c", null ],
    [ "reframe_text_box", "classgrman_1_1_widget_text.html#a26ad03869308abed40ecaef6e9d1d46e", null ],
    [ "set_color", "classgrman_1_1_widget_text.html#a621fb4e0756cc183ee94d7c0d966ef90", null ],
    [ "set_message", "classgrman_1_1_widget_text.html#a2b908c791e86834e8961b645cf835965", null ],
    [ "set_vertical", "classgrman_1_1_widget_text.html#a03b0b3cbba6184e076fbc7894771e99e", null ],
    [ "m_color", "classgrman_1_1_widget_text.html#ae368be23564e5193942e4839ca78e913", null ],
    [ "m_font", "classgrman_1_1_widget_text.html#a22c6d8eed2c019b48df545d83e4cf5e3", null ],
    [ "m_message", "classgrman_1_1_widget_text.html#af4890cc8e49980454468109740dfe071", null ],
    [ "m_vertical", "classgrman_1_1_widget_text.html#a854e398aea75d4030389a3788382a430", null ]
];